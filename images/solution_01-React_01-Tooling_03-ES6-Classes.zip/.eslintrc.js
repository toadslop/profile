module.exports = {
  "extends": "airbnb-base",
  "rules": {
    "no-console": "off",
    "comma-dangle": "off",
    "quotes": "off",
    "arrow-body-style": 0,
    "space-before-function-paren": 0
  }
};
